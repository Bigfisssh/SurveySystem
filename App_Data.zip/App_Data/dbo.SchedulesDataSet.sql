﻿CREATE TABLE [dbo].[SchedulesDataSet] (
    [S.No]          INT          NOT NULL,
    [Sem Weeks]     INT          NOT NULL,
    [Start Date]    VARCHAR (50) NOT NULL,
    [Name]          VARCHAR (50) NOT NULL,
    [Code]          VARCHAR (50) NOT NULL,
    [Credit]        INT          NOT NULL,
    [Class Hours]   INT          NOT NULL,
    [Reserved One]  VARCHAR (50) NOT NULL,
    [Specific Date] NCHAR (10)   NOT NULL,
    PRIMARY KEY CLUSTERED ([S.No] ASC)
);


